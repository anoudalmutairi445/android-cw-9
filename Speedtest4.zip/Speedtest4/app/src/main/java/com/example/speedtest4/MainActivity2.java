package com.example.speedtest4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle aie = getIntent().getExtras();
      Pokemon p = (Pokemon) aie.getSerializable("pokemon");

        ImageView img = findViewById(R.id.pic);
        TextView name = findViewById(R.id.name2);
        TextView defense = findViewById(R.id.defence);
        TextView attack = findViewById(R.id.attack);
        TextView total = findViewById(R.id.totall);

        img.setImageResource(p.getImage());
        name.setText(p.getName());
        defense.setText(p.getDefence()+"");
        attack.setText(p.getAttack()+"");
        total.setText(p.getTotal()+"");




    }
}